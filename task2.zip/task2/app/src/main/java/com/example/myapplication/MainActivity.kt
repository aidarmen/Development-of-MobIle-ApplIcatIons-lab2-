package com.example.myapplication


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import java.math.BigDecimal
import java.math.RoundingMode

class MainActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var num = 0
        val cream = findViewById<CheckBox>(R.id.cream)
        val choco = findViewById<CheckBox>(R.id.choco)

        val btnPlus = findViewById<Button>(R.id.plusBtn)
        val btnMinus = findViewById<Button>(R.id.minusBtn)
        val btnOrder = findViewById<Button>(R.id.order)


        val count = findViewById<TextView>(R.id.count)
        val summary = findViewById<TextView>(R.id.summary)


        btnPlus.setOnClickListener{
            num++
            count.text ="$num"
        }

        btnMinus.setOnClickListener{
            num--

            count.text ="$num"
        }

        btnOrder.setOnClickListener{
            var chocoB = choco.isChecked
            var creamB = cream.isChecked
            var text =""
            var price = 4.00

            if(creamB){
                text ="add Whipping Cream? Yes\n"
                price +=0.5

            }else{
                text ="add Whipping Cream? No\n"
            }
            if(chocoB){
                text = text  + "add chocolate? Yes\n";
                price +=1

            }else{
                text = text  + "add chocolate? No\n";

            }
            val dollar = BigDecimal(price*num).setScale(2, RoundingMode.HALF_EVEN)

            text = text +"Quantity: $num\n"
            text = text +"Price: \$$dollar\n"

            text = text +"THANK YOU!"
            summary.text = text


        }


    }






}